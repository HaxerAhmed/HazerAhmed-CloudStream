/*
 * Settings file for the Cinefreak plugin.  When using the
 * CloudStream plugin template, this file should list your
 * plugin modules.  For example:
 *
 * rootProject.name = "TestPlugins"
 * include(":Cinefreak")
 */

rootProject.name = "CinefreakPlugin"