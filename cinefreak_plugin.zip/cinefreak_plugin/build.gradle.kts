/*
 * This is a placeholder Gradle build script for the Cinefreak
 * CloudStream provider.  You should not use this file alone –
 * instead copy the contents of the official CloudStream plugin
 * template and replace the placeholders with your plugin’s
 * properties.  See the CloudStream documentation for details.
 */

plugins {
    id("cloudstream-plugin")
}

// Define your plugin's version and dependencies in the template's
// build script when integrating this provider.